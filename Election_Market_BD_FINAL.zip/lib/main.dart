
import 'package:flutter/material.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LanguageSelect(),
    );
  }
}

class LanguageSelect extends StatelessWidget {
  const LanguageSelect({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset('assets/logo.png', height: 120),
          const SizedBox(height: 20),
          const Text('ভাষা নির্বাচন করুন / Select Language',
              style: TextStyle(fontSize: 18)),
          const SizedBox(height: 20),
          ElevatedButton(
            child: const Text('বাংলা'),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const Market(isBangla: true)));
            },
          ),
          ElevatedButton(
            child: const Text('English'),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const Market(isBangla: false)));
            },
          ),
        ],
      ),
    );
  }
}

class Market extends StatefulWidget {
  final bool isBangla;
  const Market({super.key, required this.isBangla});

  @override
  State<Market> createState() => _MarketState();
}

class _MarketState extends State<Market> {
  int coins = 10000;

  final List<Map<String, dynamic>> parties = [
    {'bn': 'বাংলাদেশ আওয়ামী লীগ', 'en': 'Awami League', 'price': 500, 'own': 0},
    {'bn': 'বিএনপি', 'en': 'BNP', 'price': 450, 'own': 0},
    {'bn': 'জাতীয় পার্টি', 'en': 'Jatiya Party', 'price': 300, 'own': 0},
    {'bn': 'জামায়াতে ইসলামী', 'en': 'Jamaat-e-Islami', 'price': 280, 'own': 0},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isBangla ? 'Election Market BD' : 'Election Market BD'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              (widget.isBangla ? 'কয়েন: ' : 'Coins: ') + coins.toString(),
              style: const TextStyle(fontSize: 18),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: parties.length,
              itemBuilder: (_, i) {
                final p = parties[i];
                return Card(
                  child: ListTile(
                    title: Text(widget.isBangla ? p['bn'] : p['en']),
                    subtitle: Text(
                      (widget.isBangla ? 'দাম: ' : 'Price: ') +
                          p['price'].toString() +
                          ' | ' +
                          (widget.isBangla ? 'আপনার: ' : 'Owned: ') +
                          p['own'].toString(),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.add),
                          onPressed: coins >= p['price']
                              ? () {
                                  setState(() {
                                    coins -= p['price'];
                                    p['own']++;
                                    p['price'] += 20;
                                  });
                                }
                              : null,
                        ),
                        IconButton(
                          icon: const Icon(Icons.remove),
                          onPressed: p['own'] > 0
                              ? () {
                                  setState(() {
                                    coins += p['price'];
                                    p['own']--;
                                    p['price'] -= 10;
                                  });
                                }
                              : null,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
